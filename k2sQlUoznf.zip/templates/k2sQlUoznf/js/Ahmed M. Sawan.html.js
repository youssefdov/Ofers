<!DOCTYPE HTML>
<html>



<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>apk</title>
<link rel="stylesheet" href="css/framework7.ios.min.css">
<link rel="stylesheet" href="css/framework7.ios.colors.min.css">
<link rel="stylesheet" href="css/appvalley.css">


<script type="text/javascript" src="js/framework7.min.html"></script>
</head>
<body id="body">
<div class="statusbar-overlay"></div>
<div class="views tabs navbar-through toolbar-through">
<div id="tab-1" class="view view-main tab active">
<div class="pages">
<div data-page="index" class="page">
<div class="page-content pull-to-refresh-content" data-ptr-distance="55">
<div class="pull-to-refresh-layer">
<div class="preloader"></div>
</div>
<div class="content-block">
<h5 style="margin-bottom:0px;margin-top:-48px;">
</h5>

</label>
</form>
</div>
<center>
<div class="hr"></div>
<div class="content-block" style="max-width:414px; margin: 16px; margin-left: -16px;">
<div class="app-card">
<div class="list-block">
<div class="item-content">
<div class="item-inner">
<div class="item-title"> <center>Hurry up before the end of the apk!</center> </div>
</div>
</div>
</div>
</div>
<div class="app-card">
<img class="app-icon" src="i.imgur.com/AZ5aqzF.png">
<div class="list-block">
<div class="item-content">
<div class="item-media">
</div>
</div>
</div>
</div>


<div class="app-card-2">
<div class="content-block" style="margin-top:0px; margin-bottom:0px; padding-top:10px; padding-bottom:10px;">
<h4 style="margin:0px;">FEATURED</h4>
<h2 class="header" style="margin:0px;">Featured</h2>
</div>
<div class="list-block media-list">
<ul>

<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan15.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">Threads</div>
<div class="item-after">
<a href="https://website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the apk now</a>
</div>
</div>
<div class="item-subtitle"> Lots of apk are waiting for you now </div>
</div>
</div>
<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan14.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">Remini</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the apk now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>
<div class="item-content">
<div class="item-media"><img class="app-icon" src="i.imgur.com/AhmedSawan13.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">PicsArt</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>
<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan12.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">KINEMASTER</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>
<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan1.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">VN VIDEO EDITOR</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>


<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan2.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">BAZAART</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>















<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan3.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">PHOTOSHOP 2023</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>
<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan4.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">SNAPSEED</div>
<div class="item-after">
 <a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>
<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan5.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">WHATSAPP Gold </div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>

<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan6.jpg"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">HMA VPN</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>

<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan7.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">2NDLINE </div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>
<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan8.jpg"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">WHATSAPP PLUS</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>

<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan11.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">TRUECALLER</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>

<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan10.png"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">Adobe Lightroom</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>

<div class="item-content">
<div class="item-media"><img class="app-icon" src="content/icon/AhmedSawan9.jpg"></div>
<div class="item-inner">
<div class="item-title-row">
<div class="item-title">InShot</div>
<div class="item-after">
<a href="https:///website.com" class="button button-fill button-round" style="background: #F0F1F6; color: #007AFF; font-weight:bold;">Get the gift now</a>
</div>
</div>
<div class="item-subtitle">Lots of apk are waiting for you now</div>
</div>
</div>

</ul>
</div>
<br>
</div>



</div>
</ul>
</div>
<br>
</div> 
</div>
<br>
</center>
</div>
</div>
</div>
</div>
</div>



</div>
<script type="text/javascript" src="js/Ahmed M. Sawan.html"></script>
</body>


</html>
